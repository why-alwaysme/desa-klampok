<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Model_login_admin');
        $this->load->model('Model_posyandu');
    }

    public function index()
    {
        $validation = $this->form_validation;
        $validation->set_rules('user', 'Username', 'trim|required');
        $validation->set_rules('pass', 'Password', 'trim|required');

        if ($validation->run() == false) {
            $data['title'] = 'Login Admin';
            $this->load->view('Admin/login', $data);
        } else {
            $this->_login();
        }
    }

    private function _login()
    {
        $username = $this->input->post('user');
        $password = $this->input->post('pass');
        $user = $this->Model_login_admin->get($username);

        if ($user) {
            if ($password == $user->password_admin) {
                $session = array(
                    'authenticated' => true,
                    'username' => $user->username,
                    'password' => $user->password
                );
                $this->session->set_userdata($session);
                $this->session->set_userdata(['user_logged' => $user]);
                redirect('Admin/Dashboard');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
			Password Salah!
		    </div>');
                redirect('Admin');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
			Username Salah!
		    </div>');
            redirect('Admin');
        }
    }

    public function Dashboard()
    {
        if ($this->Model_login_admin->isNotLogin()) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
			Anda belum Login!
		    </div>');
            redirect('Admin');
        }
        $data['jumlah'] = $this->Model_posyandu->jumlah_pendaftar();
        $data['title'] = 'Admin';
        $this->load->view('Admin/v_dashboard', $data);
    }

    public function logout()
    {
        $this->session->sess_destroy();
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Anda berhasil Logout!
		    </div>');
        redirect('Admin');
    }

    public function Posyandu()
    {
        if ($this->Model_login_admin->isNotLogin()) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
			Anda belum Login!
		    </div>');
            redirect('Admin');
        } else {
            $data['info'] = $this->Model_posyandu->get_info();
            $data['jumlah'] = $this->Model_posyandu->jumlah_pendaftar();
            $data['judul'] = 'Informasi Posyandu';
            $this->load->view('admin/v_posyandu', $data);
        }
    }

    public function Data_Posyandu()
    {
        if ($this->Model_login_admin->isNotLogin()) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
			Anda belum Login!
		    </div>');
            redirect('Admin');
        } else {

            $cari = $this->input->post('cari');
            if ($cari != '') {
                $data['query'] = $this->Model_posyandu->cari_nama($cari);

                $data['title'] = "Data Posyandu";
                $this->load->view('admin/v_data_posyandu', $data);
            } else {
                $data['query'] = $this->Model_posyandu->get_data();

                $data['title'] = "Data Posyandu";
                $this->load->view('admin/v_data_posyandu', $data);
            }
        }
    }

    public function Edit()
    {
        if ($this->Model_login_admin->isNotLogin()) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
			Anda belum Login!
		    </div>');
            redirect('Admin');
        } else {
            $validation = $this->form_validation;
            $validation->set_rules(
                'tanggal',
                'Tanggal',
                'required|trim',
                [
                    'required' => 'Tanggal Tidak Boleh Kosong!'
                ]
            );
            $validation->set_rules(
                'tempat',
                'Tempat',
                'required|trim',
                [
                    'required' => 'Tempat Tidak Boleh Kosong!'
                ]
            );
            $validation->set_rules(
                'keterangan',
                'Keterangan',
                'required|trim',
                [
                    'required' => 'Beri Keterangan Posyandu!'
                ]
            );
            if ($validation->run() == false) {
                $data['info'] = $this->Model_posyandu->get_info();
                $this->load->view('admin/v_edit', $data);
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
                    Gagal Update Posyandu!
                </div>');
            } else {
                $this->Aksi_edit();
            }
        }
    }


    public function Aksi_edit()
    {
        if (isset($_POST['update'])) {
            $this->Model_posyandu->edit();
            redirect(site_url('Admin/Posyandu'));
        }
    }
}
