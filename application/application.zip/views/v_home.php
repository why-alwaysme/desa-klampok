<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" type="image/icon" href="<?= base_url('') ?>/frontend/assets/logo/favicon.png" />
	<title>Desa Klampok</title>

	<link href="https://fonts.googleapis.com/css?family=Rufina:400,700" rel="stylesheet" />
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet" />
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/font-awesome.min.css" />
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/animate.css" />
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/hover-min.css">
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/datepicker.css">
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/owl.theme.default.min.css" />
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/jquery-ui.min.css" />
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/bootstrap.min.css" />
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/bootsnav.css" />
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/style.css" />
	<link rel="stylesheet" href="<?= base_url('') ?>/frontend/assets/css/responsive.css" />
</head>

<body>

	<?php include('template/navbar.php'); ?>


	<section id="home" class="about-us">
		<div class="container">
			<div class="about-us-content">
				<div class="row">
					<div class="col-sm-12">
						<div class="single-about-us">
							<div class="about-us-txt">
								<h2>
									Explore the Beauty of Beautiful Klampok
									<br>
									Kab. Malang
								</h2>
								<div class="about-btn col-sm-2">
									<button class="about-view">
										explore now
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</section>

	<script src="<?= base_url('') ?>/frontend/assets/js/jquery.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/bootstrap.min.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/bootsnav.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/jquery.filterizr.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/jquery-ui.min.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/jquery.counterup.min.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/waypoints.min.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/owl.carousel.min.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/jquery.sticky.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/datepicker.js"></script>
	<script src="<?= base_url('') ?>/frontend/assets/js/custom.js"></script>
</body>

</html>