<?php
class Model_login_admin extends CI_Model{
	public function __construct()
	{
    	parent::__construct();
	}

  public function get($username){
        $this->db->where('username_admin', $username); // Untuk menambahkan Where Clause : username='$username'
        $result = $this->db->get('admin')->row(); // Untuk mengeksekusi dan mengambil data hasil query
        return $result;
      }
    public function isNotLogin(){
        return $this->session->userdata('user_logged') === null;
    }

}
?> 
